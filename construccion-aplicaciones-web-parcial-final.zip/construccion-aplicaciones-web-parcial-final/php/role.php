<?php

enum Role: int
{
    case CLIENT = 1;
    case SUPPLIER = 2;
    case ADMIN = 3;
    case SHARED = 4;
}
